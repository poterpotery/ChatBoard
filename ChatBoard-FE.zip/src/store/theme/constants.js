export const COLORS = {

}