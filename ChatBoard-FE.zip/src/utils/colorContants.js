export const APP_COLORS = {
    // orange shade colors
    gradientLight: '#F7F3EF',
    gradientDark: '#F7F3EF',


    // blue shade colors
    // gradientLight: '#1E90FF',
    // gradientDark: '#26619c'
}