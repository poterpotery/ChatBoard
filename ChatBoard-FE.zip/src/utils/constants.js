export const ACTIVE_OPACITY=0.8
// export const BASE_URL=0.8