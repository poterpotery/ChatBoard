/**
 * This file contains all application's style relative to fonts
 */
import { StyleSheet } from 'react-native';
export default function ({ FontSize, Colors }) {
    return StyleSheet.create({
        textLobster: {
            fontFamily: 'lobster',
        },
    });
}
