import * as default_dark from './default_dark';
export default {
    default_dark,
};
