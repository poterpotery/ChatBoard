/**
 * Images should be stored in the `App/Images` directory and referenced using variables defined here.
 */
export default function () {
    return {
        splash: require('../../assets/images/splash.png'),
    };
}
