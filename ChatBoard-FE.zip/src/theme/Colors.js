export default function () {
  return {
    primaryColor: '#7FCE00',
    secondaryColor: '#9DFF00',

  };
}
export const COLORS = {
  primaryColor: '#7FCE00',
  secondaryColor: '#9DFF00',
  
}