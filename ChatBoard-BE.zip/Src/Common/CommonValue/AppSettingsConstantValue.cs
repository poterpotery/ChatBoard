﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.CommonValue
{
    public static class AppSettingsConstantValue
    {
        public const string message = "read";

    }
}
