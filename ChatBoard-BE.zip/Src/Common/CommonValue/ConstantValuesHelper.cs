﻿using System;
namespace Common.CommonValue
{
    public static class ConstantValuesHelper
	{
        public const string Base = "https://localhost:5000";


    }
}
