﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Helpers.FriendRequestCommons
{
    public static class GenderCommons
    {
        public const string Male = "Male";
        public const string Female = "Female";
    }
}
