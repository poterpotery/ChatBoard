﻿namespace DTO.ViewModel.Account
{
    public class VerifyEmailRequestModel
    {
        public string Token { get; set; }
        public string Email { get; set; }
    }
}
