﻿using System;
namespace DTO.ViewModel.Account
{
    public class ConfirmTokenChangePasswordRequestModel
    {
        public string Token { get; set; }
    }
}

