﻿namespace DTO.ViewModel.Account
{
    public class AppSettingsResponseModel
    {
        public long Id { get; set; }
        public string keyword { get; set; }
        public string value { get; set; }
    }
}
