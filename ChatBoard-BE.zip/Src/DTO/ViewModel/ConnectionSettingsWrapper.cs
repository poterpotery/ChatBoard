﻿using System;
namespace DTO.ViewModel
{
	public class ConnectionSettingsWrapper
	{
        public string MASTERPARTIALKEY { get; set; }
        public string SLAVEDB { get; set; }
        public string MASTERDB { get; set; }
    }
}

