﻿using System;
namespace DTO.Enums
{
    public enum ActionType
    {
        Add = 1,
        Update = 2,
        Delete = 3,
        Block = 4,
        SignUp= 5,
        Login=6,
    }
}

