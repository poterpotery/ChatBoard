﻿using System;
namespace DTO.Enums
{
	public enum FeedbackEnum
	{
	}
}

