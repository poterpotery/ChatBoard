﻿namespace DTO.Enums
{
    public enum FileStorageType
    {
        Internal = 0,
        ExternalLink = 1
    }
}
