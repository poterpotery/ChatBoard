﻿public enum AccountStatusEnum
{
    None = 0,
    Active = 1,
    Deactive = 2
}