﻿using System;
namespace DTO.Enums
{
	public enum EMeterType
	{
		Electricity = 1,
		Gas = 2,
		Other = 3,
		Water = 4
	}
}

