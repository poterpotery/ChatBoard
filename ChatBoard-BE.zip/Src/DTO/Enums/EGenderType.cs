﻿using System;
namespace DTO.Enums
{
	public enum EGenderType
	{
		Male = 1,
		Female = 2,
		Others = 3
	}
}

