﻿public enum AccountBlockEnum
{
    None = 0,
    MyAccount = 1,
    OtherUser = 2
}