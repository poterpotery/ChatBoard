﻿using System;
namespace DTO.Enums
{
    public enum EAccountType
    {
        User = 1,
        SuperAdmin = 2,
        SubAdmin = 3,
        Supplier = 4
    }
}

