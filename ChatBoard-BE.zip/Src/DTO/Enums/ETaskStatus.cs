﻿using System;
namespace DTO.Enums
{
	public enum ETaskStatus
	{
		Pending = 1,
		InProgress = 2,
		Complete = 3,
		NotComplete = 4
	}
}

