﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO.Enums
{
    public enum PrivacyEnum
    {
        Public = 1,
        Private = 2
    }
}
