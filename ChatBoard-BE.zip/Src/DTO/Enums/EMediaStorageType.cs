﻿using System;
namespace DTO.Enums
{
	public enum EMediaStorageType
	{
		Cloudinary = 1,
		Backblaze = 2
	}
}

